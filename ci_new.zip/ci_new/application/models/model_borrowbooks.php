<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class model_borrowbooks extends CI_Model {


	private $borrow_tbl = "borrow";
	private $student_tbl = "student";
	private $book_tbl = "books";
	
	
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
	
	
	public function Get_all_student_who_borrow($search_student)
	{
		
		
		
	/* 	$query = $this->db
				->select("t1.borrow_id,t2.id,t2.fname,t2.lname")
				->join($this->student_tbl.' '.'as t2', 't1.student_id = t2.id', 'left');
				->group_by('t2.id') 
				->get($this->borrow_tbl.' '.'as t1') */;
				
				
		$this->db->select("t1.borrow_id,t2.id,t2.fname,t2.lname");	
		$this->db->join($this->student_tbl.' '.'as t2', 't1.student_id = t2.id', 'left');	
		$this->db->group_by('t2.id');

		!empty($search_student) ? $this->db->or_like('t2.fname', $search_student):'';
		!empty($search_student) ? $this->db->or_like('t2.lname', $search_student):'';
		
		$query = $this->db->get($this->borrow_tbl.' '.'as t1');
		
		return $query->result();	
	}
	
	
	public function get_all_borrow_books($student_id,$search_book)
	{
	
		$this->db->select("t2.id as bookid,t1.borrow_id,DATE_FORMAT(t1.due_date,'%Y/%m/%d') AS due_date,t2.title");
		$this->db->from($this->borrow_tbl.' '.'as t1');
		$this->db->join($this->book_tbl.' '.'as t2', 't1.book_id = t2.id', 'left'); 
		
		empty($search_book) ? $this->db->where('t1.borrow_status',"borrow") : '';
		empty($search_book) ? $this->db->where('t2.book_status',"out") : '';
		
		!empty($search_book) ? $this->db->or_like('t2.title', $search_book):'';	
		!empty($student_id) ? $this->db->where('t1.student_id',$student_id):'';
		
		
		
		$query = $this->db->get();
		return $query->result();	
	}
	
		
	
	public function get_borrow_details($borrow_id)
	{
		$select = "DATE_FORMAT(t1.due_date,'%Y/%m/%d') as due_date";
		$select.= ",DATE_FORMAT(t1.borrow_date,'%Y/%m/%d') as borrow_date";
		$select.= ",t3.*";
		$select.= ",CONCAT(t2.fname ,' ',t2.lname) as fullname";

		$query = $this->db
				->select($select)
				->join($this->student_tbl.' '.'as t2', 't1.student_id = t2.id', 'left')
				->join($this->book_tbl.' '.'as t3', 't1.book_id = t3.id', 'left')
				->where('t1.borrow_id',$borrow_id)
				->get($this->borrow_tbl.' '.'as t1');
		
		return $query->row();
		
	}

	
	
	public function Saveborrow($data)
	{
		$this->db->insert($this->borrow_tbl, $data);
		return $this->db->insert_id();
	}
	
	
	
	public function updateStatusbook($updateStat,$where)
	{
		$this->db->update($this->book_tbl,$updateStat,$where);
		return $this->db->affected_rows();
	}
	
	public function Updateborrow($where,$data)
	{
		$this->db->update($this->borrow_tbl,$data,$where);
		return $this->db->affected_rows();
		
	}
	
	
	public function get_borrowerbook($id)
	{
		
		$select = "DATE_FORMAT(t1.due_date,'%Y/%m/%d') as due_date";
		$select.= ",DATE_FORMAT(t1.borrow_date,'%Y/%m/%d') as borrow_date";
		$select.= ",DATE_FORMAT(t1.date_return,'%Y/%m/%d') as date_return";
		$select.= ",t1.borrow_status,t1.remarks";
		$select.= ",CONCAT(t2.fname ,' ',t2.lname) as fullname";

		$query = $this->db
				->select($select)
				->join($this->student_tbl.' '.'as t2', 't1.student_id = t2.id', 'left')
				->join($this->book_tbl.' '.'as t3', 't1.book_id = t3.id', 'left')
				->where('t3.id',$id)
				->get($this->borrow_tbl.' '.'as t1');
		
		return $query->result();
		
		
	}

}