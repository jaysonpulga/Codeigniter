<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class model_student extends CI_Model {
	
	/****
	--->table name for student
	****/
	private $student_tbl = "student";
	
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	public function Get_all_Student()
	{
		$query = $this->db->get($this->student_tbl);
		return $query->result_array();
	}
	
	
	public function Savestudent($data)
	{
		$this->db->insert($this->student_tbl, $data);
		return $this->db->insert_id();
	}
	
	
	public function Updatestudent($where,$data)
	{
		$this->db->update($this->student_tbl,$data,$where);
		return $this->db->affected_rows();
	}
	
	public function Deletestudent($id)
	{
		$this->db->where('id', $id);
		$this->db->delete($this->student_tbl);
	
	}
	
	
	public function Get_student_byID($id)
	{
		$this->db->from($this->student_tbl);
		$this->db->where('id',$id);
		$query = $this->db->get();
		return $query->row();
		
	}


}