<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class model_books extends CI_Model {
	
	/****
	--->table name for books
	****/
	private $book_tbl = "books";
	private $borrow_tbl = "borrow";
	private $student_tbl = "student";
	
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	public function Get_all_Books()
	{
		
			$select = "t1.*";
			$select.= ",(CASE when (t2.student_id is not NULL and t2.borrow_status = 'borrow') then CONCAT(t3.fname ,' ',t3.lname) else '' end) as fullname";
			
			$this->db->select($select);
			$this->db->from($this->book_tbl.' '.'as t1');
			$this->db->join($this->borrow_tbl.' '.'as t2', 'on t2.book_id = t1.id AND t2.borrow_status = "borrow"','left');
			$this->db->join($this->student_tbl.' '.'as t3', 'on t2.student_id = t3.id','left');	
			$this->db->group_by("t1.id","t2.book_id");
			$query = $this->db->get();
			return $query->result(); 
			
			
			
			
			
	}
	
	
	
		public function Get_borrowbook_DetailbyID($book_id)
	{
					
			$select = "t1.*,t3.id as student_id,t2.borrow_id,t1.id as bookid";
			$select.= ",DATE_FORMAT(t2.due_date,'%Y-%m-%d') as due_date";
			$select.= ",DATE_FORMAT(t2.borrow_date,'%Y-%m-%d') as borrow_date";
			

			$this->db->select($select);
			$this->db->from($this->book_tbl.' '.'as t1');
			$this->db->join($this->borrow_tbl.' '.'as t2', 'on t2.book_id = t1.id AND t2.borrow_status = "borrow" ','left');
			$this->db->join($this->student_tbl.' '.'as t3', 'on t2.student_id = t3.id','left');			
			$this->db->where('t1.id',$book_id);		
			$this->db->group_by("t1.id,t2.borrow_id");
			$query = $this->db->get();
			return $query->row();
		
	}

	
	
	public function Savebook($data)
	{
		$this->db->insert($this->book_tbl, $data);
		return $this->db->insert_id();
	}
	
	
	public function Updatebook($where,$data)
	{
		$this->db->update($this->book_tbl,$data,$where);
		return $this->db->affected_rows();
	}
	
	public function Get_book_byID($id)
	{
		$this->db->select("*,DATE_FORMAT(date,'%Y-%m-%d') as date");
		$this->db->from($this->book_tbl);
		$this->db->where('id',$id);
		$query = $this->db->get();
		return $query->row();
		
	}
	
	public function getImagespath($id)
	{
		
		$this->db->select("images");
		$this->db->from($this->book_tbl);
		$this->db->where('id',$id);
		$query = $this->db->get();
		$image =  $query->row();
		return $image->images;
		
	}
	
	

}