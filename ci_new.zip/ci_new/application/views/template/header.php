<!DOCTYPE html>
<html lang="en">
<head>
		<meta charset="utf-8">
		<title><?php echo $title; ?></title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
		
		

		<!-- Bootstrap Core CSS file -->
		<link rel="stylesheet" href="assets/css/bootstrap.min.css">
		
		
		

		<!-- Override CSS file - add your own CSS rules -->
		<link rel="stylesheet" href="assets/css/styles.css">
		
	
		<!-- Overwrite CSS file  -->
		<link rel="stylesheet" href="assets/css/overwright.css">
		
		
		<!-----#### put on the footer ###----->
		<!-- JQuery scripts -->
		 <script src="assets/js/jquery-2.1.1.min.js"></script>

		 
		<!-- Bootstrap Core scripts -->
		<script src="assets/js/bootstrap.min.js"></script>

		<!-- Bootstrap Core scripts -->
		<script src="assets/js/bootbox/bootbox.min.js"></script>
		
		
		
		
	 

		<!-- Conditional comment containing JS files for IE6 - 8 -->
		<!--[if lt IE 9]>
			<script src="assets/js/html5.js"></script>
			<script src="assets/js/respond.min.js"></script>
		<![endif]-->
		

<div id = "blocker" style = "position:fixed;z-index:9999;width:100%;height:100%;display:none;background:#000;top:0;left:0;opacity:0.2;"></div> 
<div id = "loader" style = "position:fixed;z-index:9999;top:0;bottom:0;left:0;right:0;margin:auto;width:219px;height:20px;display:none"><img class="img-responsive" src="assets/img/ajax-loader.gif" /><center></center></div>
		
		

</head>

	<body>
	
	
		<!-- Navigation -->
		<nav class="navbar navbar-fixed-top navbar-inverse" role="navigation">
			<div class="container-fluid">

				<!-- Brand and toggle get grouped for better mobile display -->
				<div class="navbar-header">
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					
					<!-- <span><img class="navbar-img"   src="assets/img/logo.png" alt="" /></span> -->
					
					 <a class="navbar-brand" href="#">
						<img src="assets/img/logonew.png"  alt="">
					</a>
					
				</div>
				<!-- /.navbar-header -->

				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					<ul id='menu-main' class="nav navbar-nav navbar-right">
						<li><a class="selected" href="#home">Home</a></li>
						<li><a href="#library">Library</a></li>
						<li><a href="#student">Student</a></li>
						<li><a href="#books">Books</a></li>
					</ul>
				</div>
				<!-- /.navbar-collapse -->
			</div>
			<!-- /.container-fluid -->
		</nav>
		<!-- /.navbar -->