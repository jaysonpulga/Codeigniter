		
		
		<div class="container-fluid">
		
	
				<!-- footer section  -->
				<div style="position:relative;bottom:0;">
						<hr>
						<footer class="margin-tb-3">
							<div class="row">
								<div class="col-lg-12">
									<center><p>Copyright &copy; jaysonpulga 2017</p></center>
								</div>
							</div>
						</footer>
				</div>
				<!--  end of footert -->
		
		
		
		</div>
			

	</body>
</html>








