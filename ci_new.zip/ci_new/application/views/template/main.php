
		<!-- Page Content -->
		<div class="container-fluid">
		
				<!-- clear space -->	
				<div class="clear_space_big"></div>
				<!-- end of clear space -->
			
				<div id="div_container"></div>	
				
				
		</div>
		<!-- /.container-fluid -->		

		


<script>
$(document).ready(function(){
	
	// default page	view  ---homepage
	append_ajax('<?php echo site_url('Dashboard/load_page')?>','POST',{page_name:"home"});
});


function view_deatil()
{	
	var options = { backdrop : 'static'}
	$('#book_detail').modal(options);
}







/**
 * Action load for every pages
 *
 */

$('#menu-main li a').click(function(event){
 
	event.preventDefault();
	
	var links = $('#menu-main li a');
	links.removeClass('selected');
	$(this).addClass('selected');
	
	var page = this.hash;
	page=page.replace('#','');
			
	append_ajax('<?php echo site_url('Dashboard/load_page')?>','POST',{page_name:page});		
	//append_ajax("Dashboard/load_page",'POST',{page_name:page});

});
	 
	
	
	
/**
 * This function will append the requested data into the selected element
 *
 * @param url [string]
 * @param method [string]
 * @param params [array]
 */
function append_ajax(url,method,params)
{
	 $.ajax({
		 
			url		:	url,
			
			type	:	method,
			
			data	:	params,
			
			beforeSend: function(){
				
					/* $("#blocker").css("display","block");
					$("#loader").css("display","block"); */
						
			},
			success	:	function(response)
			{
				
			
			/* 	$("#blocker").css("display","none");
				$("#loader").css("display","none"); */
				
				$("#div_container").empty();
				$("#div_container").append(response);
		}
		
	}); 
}
	
	 
	
	
	 
</script>
