<!-- Projects Row 3 -->
<div class="row">
	<div class="col-md-12" >
					
				<div class="col-md-12" >
					<span class="pull-left" style='font-size:25px'>List of Books</span>
					<button id='add_new_button' onclick="add_new_book()" class="btn btn-success btn-sm pull-right" >
						<span  class="glyphicon glyphicon-plus m-right"></span>Add New Book
					</button>
				</div>

				<div class="page-header"></div>
				<div class="clear_space_small"></div>
				
				<div class="col-md-12" >
					<div id="Message"  role="alert">
						<strong>Well done! </strong><span id="msg_result"></span>
					</div>
				</div>
				
				
				
				<div class="panel-body">
						<table id='test' class="table table-bordered table-hover">
							<thead>
								<tr>
									<th></th>
									<th>Title</th>
									<th>Author</th>
									<th>Book Directory</th>
									<th>Genre</th>
									<th>Status</th>
									<th>borrower</th>
									<th>Action</th>
								</tr>
							</thead>
							<tbody></tbody>
						</table>
				</div>
	</div>
</div>
		

<!--  END OF ROW 3  -->



<script>
var save_method; //for save method string
var save_rentBook; //for save method string

$(document).ready(function(){
	loadbooks();
	
});

function loadbooks()
{
		
	var container = $("#test > tbody");
	var dataTable;
	
	 $.ajax({
		 
			url		 :	"<?php echo site_url('books/get_all_book_data')?>",
			dataType : 	"json",
			beforeSend: function(){
				
				
						
			},
			success	:	function(response)
			{
				
				if(response.length > 0)
				{
						container.empty();
						$.each(response, function(i,res){
							console.log(res);
						
									
									
								dataTable += '<tr>';
								
										dataTable += '<td>' + "<img  class='img-responsive' src='<?php echo base_url('assets/book_image/')?>"+res.images+"' />" + '</td>';
										dataTable += '<td>' + res.title + '</td>';
										dataTable += '<td>' + res.author + '</td>';
										dataTable += '<td>' + res.book_dir + '</td>';
										dataTable += '<td>' + res.genre + '</td>';
										dataTable += '<td>' + res.book_status + '</td>';
										dataTable += '<td>' + res.fullname + '</td>';
									
							
										
										
										dataTable += '<td>';
											dataTable += '<div class = "btn-group">';
											dataTable += '<button type = "button" class = "btn btn-primary dropdown-toggle" data-toggle = "dropdown">Action<span style="margin-left:10px" class = "caret "></span></button>';
												dataTable +='<ul class = "dropdown-menu" role = "menu">';
												
													dataTable += '<li>';
														dataTable +='<a onclick=\"editBook('+res.id+');\" href="#" ><i class="glyphicon glyphicon-pencil glypicon_margin"></i>Edit</a>';
													dataTable += '</li>';
													
													dataTable += '<li>';
														dataTable +='<a onclick=\"viewdetails('+res.id+');\" href="#" ><i class="glyphicon glyphicon-eye-open glypicon_margin"></i>view details</a>';
													dataTable += '</li>';
													
													
													dataTable += '<li>';
														dataTable +='<a onclick=\"viewborrower('+res.id+');\" href="#" ><i class="glyphicon glyphicon-list-alt glypicon_margin"></i>view borrower</a>';
													dataTable += '</li>';
													
												dataTable += '</ul>';
												dataTable += '</div>';										
										dataTable += '</td>';
								
								
								dataTable += '</tr>';										
			
						});
				
				
		
				}
				else
				{
					dataTable += '<tr>';
					dataTable += '<td colspan="10" ><center>No Data Found !!!!</center></td>';	
					dataTable += '</tr>';
				}		

				container.hide().append(dataTable).animate({ opacity: "show" }, "slow");
			}
			
		}); 
		
}




/**************

Display All error 
All field that need to input by the user
**************/

function DisplayError(results)
{
	
	if (results.length > 0) { 
		// iterating through the results array
		for(var i = 0; i < results.length; i++) {  
			var columnsIn = results[i];
			// loop through every key in the object
			for(var key in columnsIn){
				
				//display the column name and its value
				//console.log(key + ' : ' + results[i][key]); 
				
				 $("#val_"+key).css('display','inline').empty().append(results[i][key]);
				
			} 
		}
	}
}


	
/****************
funtion save - add new record and update existing  data
******************/
function savebook()
{
    $('#btnSave').text('saving...'); //change button text
    $('#btnSave').attr('disabled',true); //set button disable 
    var url;

    if(save_method == 'add') {
        url = "<?php echo site_url('books/add_book_data')?>";
    } else {
        url = "<?php echo site_url('books/update_book_data')?>";
    }

	 var formData = new FormData( $("#formbook")[0] );
	
    // save data to database
    $.ajax({
        url : url,
		type: "POST",
		//data: $('#formbook').serialize(),
		data : formData,
		cache : false,
		contentType : false,
		processData : false,
        dataType: "JSON",
        success: function(data)
        {

		
			if(data.status === true) //if success close modal and reload student table
            {
                $('#modal_form_book').modal('hide');
				loadbooks();
				showMessage(data.msg_result,data.addclass); // dispaly the successful message 
				setTimeout(function(){hideMessage() },3000);
            }
			else if(data.status === false) //Display Error 
			{
				DisplayError(data.error);	
			}

            $('#btnSave').text('save'); //change button text
            $('#btnSave').attr('disabled',false); //set button enable 


        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error adding / update data');
            $('#btnSave').text('save'); //change button text
            $('#btnSave').attr('disabled',false); //set button enable 

        }
    });
}



/****************
Add new book
****************/

function add_new_book()
{
	save_method = 'add';
    $('#formbook')[0].reset(); // reset form on modals
    $('#modal_form_book').modal('show'); // show bootstrap modal
    $('.modal-title').text('Add Book'); // Set Title to Bootstrap modal title
	RemoveError(); //clear error class remove validation1 class

}
	




/****************
get the data by id
****************/
function editBook(id)
{
        

	save_method = 'update';
    $('#formbook')[0].reset(); // reset form on modals
	RemoveError(); //clear error class remove validation1 class


    //Ajax Load data from ajax
    $.ajax({
			url 		: "<?php echo site_url('books/get_book_data_byID')?>",
			data		: {"id":id}	,
			type		: "POST",
			dataType	: "JSON",
			success		: function(data){
				
							$('[name="id"]').val(data.id);
							$('[name="title"]').val(data.title);
							$('[name="author"]').val(data.author);
							$('[name="book_dir"]').val(data.book_dir);
							$('[name="genre"]').val(data.genre);
							$('[name="date"]').val(data.date);
							$('#modal_form_book').modal('show'); // show bootstrap modal when complete loaded
							$('.modal-title').text('Edit Book'); // Set title to Bootstrap modal title

			},
			error: function (jqXHR, textStatus, errorThrown){
				alert('Error get data from ajax');
			}
    });
}










function RemoveError()
{
	$(".validation1").empty().css("display","none");
}


function hideMessage()
{
    $("#Message").fadeOut('slow');
}


function showMessage(msg_result,addclass)
{	
	$("#Message").removeAttr( "class" );
	$("#Message").addClass(addclass);
    $("#Message").css("display","block");
	$("#Message #msg_result").text(msg_result);
	
}







function viewdetails(book_id)
{	
	
	//listofStudent();// call list of student and show as drop down
	
	//Ajax Load data from borrow, books and student table
	$.ajax({
			url 		: "<?php echo site_url('books/get_borrowbook_Details_byID')?>",
			data		: {"book_id":book_id}	,
			type		: "POST",
			dataType	: "JSON",
			success		: function(data){
				
						
						
						$('#borrow_id').val(data.borrow_id);
						$('#bookid').val(data.bookid);
						$('#status').empty().append(data.book_status);
						$('#title').empty().append(data.title);
						$('#author').empty().append(data.author);
						$('#genre').empty().append(data.genre);
						$('#image_src').attr("src","<?php echo base_url('assets/book_image/')?>"+data.images);
						
				
						if(data.book_status == "out")
						{
							save_rentBook = "edit"; // method for updating 
							$('#student_list').val(data.student_id);					
							$('#date_borrow').val(data.borrow_date);
							$('#date_due').val(data.due_date);
							Defaultbutton();
							
	
						}
						else
						{
							save_rentBook = "add"; // method for add new data 
							$('#student_list').attr("disabled",false);					
							$('#date_borrow').val("").attr("disabled",false);
							$('#date_due').val("").attr("disabled",false);
							
							$("#button1").css("display","none");
							$("#button2").css("display","block");
							$("#button3").css("display","none");
							
						}	
							
						var options = { backdrop : 'static'}
						$('#book_detail').modal(options); // show bootstrap modal when complete loaded
							
			},
			error: function (jqXHR, textStatus, errorThrown){
				alert('Error get data from ajax');
			}
    });
	
}






function listofStudent()
{
	var list_student = $("#student_list");
	
	 $.ajax({
		 
			url 		: "<?php echo site_url('student/get_all_student_data')?>",
			type		:	"POST",
			dataType 	: 	"JSON",
			
			success		:	function(response)
			{
				list_student.empty();
				list_student.append('<option value="">Select Student</option>');
				
				$.each(response, function(i,res)
				{
				
					list_student.append("<option value="+res.id+">"+res.fname+" "+res.lname +"</option>");
				});
			
			}
		
	}); 
}


function saveBorrow()
{
	$('#btnBookborrow').text('saving...'); //change button text
    $('#btnBookborrow').attr('disabled',true); //set button disable 
    var url;
	

    if(save_rentBook == 'add') {
        url = "<?php echo site_url('borrow/add_BookBorrow')?>";
    } else {
        url = "<?php echo site_url('borrow/update_BookBorrow')?>";
    }
	

	 $.ajax({
		 
			url  : url,
			data : $('#bookrent').serialize(),
			type : "POST",
			dataType : "JSON",
			
			success : function(data)
			{

				
		
				if(data.status === true) //if success close modal and reload student table
				{
					$('#book_detail').modal('hide');
					loadbooks();
					bootbox.alert(data.msg_result);
				}
				else if(data.status === false) //Display Error 
				{
					var error = "<center><b>Please complete The following</b><br><br>"
						error += data.error.student_list;
						error += data.error.date_borrow;
						error += data.error.date_due;
						error +="<center>";
					bootbox.alert(error);
					
				}

				$('#btnBookborrow').text('save'); //change button text
				$('#btnBookborrow').attr('disabled',false); //set button enable 
				

			},
			error: function (jqXHR, textStatus, errorThrown)
			{
				bootbox.alert('Error adding / update data');
				$('#btnBookborrow').text('save'); //change button text
				$('#btnBookborrow').attr('disabled',false); //set button enable 

			}
		
	}); 
	
	
	
}




function updateDetails()
{

$('#student_list').attr("disabled",false);					
$('#date_borrow').attr("disabled",false);
$('#date_due').attr("disabled",false);


$("#button1").css("display","none");
$("#button2").css("display","none");
$("#button3").css("display","block");	
	
	
}

function Defaultbutton()
{
	
$('#student_list').attr("disabled",true);					
$('#date_borrow').attr("disabled",true);
$('#date_due').attr("disabled",true);

$("#button1").css("display","block");
$("#button2").css("display","none");
$("#button3").css("display","none");	
	
}











function viewborrower(id)
{

var container = $("#tableborrow > tbody");
var dataTable;
	
	$.ajax({
		 
			url			: "<?php echo site_url('borrow/borrowerbook/')?>/" + id,
			dataType 	: "JSON",
			beforeSend	: function(){},
			success		:	function(response)
			{
				
				if(response.length > 0)
				{
					container.empty();
					$.each(response, function(i,res){
						console.log(res);

								dataTable += '<tr>';
									dataTable += '<td>' + res.fullname + '</td>';
									dataTable += '<td>' + res.borrow_date + '</td>';
									dataTable += '<td>' + res.due_date + '</td>';
									dataTable += '<td>' + res.borrow_status + '</td>';
									dataTable += '<td>' + res.date_return + '</td>';
									dataTable += '<td>' + res.remarks + '</td>';
								dataTable += '</tr>';
					});

				}
				else
				{
					dataTable += '<tr>';
					dataTable += '<td colspan="10" ><center>No Data Found !!!!</center></td>';	
					dataTable += '</tr>';
				}		
							
				container.hide().append(dataTable).animate({ opacity: "show" }, "slow"); // append student data display on table
			}
			
		}); 

$('#modal_borrower').modal('show'); // show bootstrap modal	
	
}
</script>






<!-- Bootstrap modal -->
<div class="modal fade" id="modal_form_book" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h3 class="modal-title">Book Form</h3>
            </div>
            <div class="modal-body form">
                <form action="#" id="formbook" class="form-horizontal" enctype="multipart/form-data">
                    <input type="hidden" value="" name="id"/> 
                    <div class="form-body">
							<div class="form-group">
								<label class="control-label col-md-3">Book title :</label>
								<div class="col-md-9">
									<input name="title" placeholder="Book Title" class="form-control" type="text">
									<span class="validation1" id='val_title' ></span>
								</div>
							</div>
							<div class="form-group">
								<label class="control-label col-md-3">Author :</label>
								<div class="col-md-9">
									<input name="author" placeholder="Author" class="form-control" type="text">
									<span class="validation1" id='val_author' ></span>
								</div>
							</div>
							<div class="form-group">
								<label class="control-label col-md-3">Directory :</label>
								<div class="col-md-9">
								   <input name="book_dir" placeholder="Book Directory" class="form-control" type="text">
									<span class="validation1" id='val_book_dir' ></span>
								</div>
							</div>
							<div class="form-group">
								<label class="control-label col-md-3">Genre :</label>
								<div class="col-md-9">
									<input name="genre" placeholder="Book Directory" class="form-control" type="text">
									<span class="validation1" id='val_genre' ></span>
								</div>
							</div>
							<div class="form-group">
								<label class="control-label col-md-3">Date :</label>
								<div class="col-md-9">
									<input name="date" placeholder="yyyy-mm-dd" class="form-control"  type="date">
									<span class="validation1" id='val_date' ></span>
								</div>
							</div>
							<div class="form-group">
								<label class="control-label col-md-3">Photo :</label>
								<div class="col-md-9">
									<input data-toggle="tooltip" data-placement="top"  title="Book Photo" class="form-control"  id="userfile" name="userfile" type="file" accept="image/*" />
									<span class="validation1" id='val_userfile' ></span>
								</div>
							</div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" id="btnSave" onclick="savebook()" class="btn btn-primary">Save</button>
                <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->









<!-- Bootstrap modal -->
<div class="modal fade" id="modal_borrower" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h3 class="modal-title">Book Borrowers</h3>
            </div>
            <div class="modal-body form">
               <div class="row">
						<div class="col-md-12">
						<div class=table-container-outer>
						<div class=table-container>
							<table id='tableborrow'>
										<thead>
											<tr>
												<th>Fullname</th>
												<th>Date borrow</th>
												<th>Date due</th>
												<th>Status</th>
												<th>Date return</th>
												<th>Remarks</th>
											</tr>
										</thead>
									<tbody></tbody>
							</table>
						</div>
						</div>		
						</div>
				</div>
			</div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->










<!--- **** --->
<div class="modal fade" id="book_detail" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			<h4 class="modal-title">
				Book Detail
			</h4>
      </div>
      <div class="modal-body">
			<div class="row">
					<div class="col-md-5">
						<center>
							<img id="image_src" style="height:auto;width:90%" src="assets/book_image/997_1.png">
						</center>
					</div>
					<div class="col-md-7">
					
							
					<form id="bookrent" method ="post">
						<table  id="over" class="table">
							  
									<input type="hidden" name="borrow_id"  id="borrow_id"/>
									<input type="hidden" name="bookid"  id="bookid"/>									
										<!---###### Default information ######------>
										<tr>
											<td><strong>Status</strong></td>
											<td>:</td>
											<td class="pull-left" id="status">Borrow</td>
										</tr>	
										<tr>
											<td><strong>Book Title</strong></td>
											<td>:</td>
											<td class="pull-left" id="title">Sample Name</td>
										</tr>	
										<tr>
											<td><strong>Author</strong></td>
											<td>:</td>
											<td class="pull-left" id='author'>James Watte</td>
										</tr>
										<tr>
											<td><strong>Genre</strong></td>
											<td>:</td>
											<td class="pull-left" id='genre'>Horor/Suspence</td>
										</tr>
										<!---###### End Default View ######------>
											
											
										<!-----#### Show borrower info if the book status is borrowed ##########  ---->
										<tr id="section_borrow_name">
											<td><strong>Student</strong></td>
											<td>:</td>									
											<td class="pull-left">
												<select name="student_list" id='student_list' class='form-control' >
												<option value="">Select Student</option>
													<?php	
															
															$student = Dashboard::callStudentController();
															foreach($student as $data => $value)
															{
																echo "<option value =".$value['id'].">".$value['lname']." ".$value['fname']."</option>";
															}
															
													?>													
												</select>
											</td>
										</tr>
										<tr id="section_borrow_date">
											<td><strong>Borrow Date</strong></td>
											<td>:</td>			
											<td class="pull-left">
												<input name="date_borrow" id='date_borrow' class='form-control' type='date'>
											</td>													
										</tr>
										<tr id="section_borrow_due">
											<td><strong>Due Date</strong></td>
											<td>:</td>									
											<td class="pull-left">
												<input name="date_due" id='date_due'  class='form-control' type='date'>
											</td>												
										</tr>
										<!--------------######## END ################3 ------>			
																
						</table>
					</form>							
					</div>	
			</div>
	  
      </div>
      <div class="modal-footer">
	  
		<div id="button1" style='display:none'>
			<button type='button' class='btn btn-success'  onclick="updateDetails()" >Update</button>
			<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
		</div>
		
		<div id="button2" style='display:none'>
			<button type='button' id="btnBookborrow" class='btn btn-primary'  onclick="saveBorrow()" >Save data</button>
			<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
		</div>
		
		<div id="button3" style='display:none'>
			<button type='button' id="btnBookborrow" class='btn btn-primary'  onclick="saveBorrow()" >Save data</button>
			<button type="button" class="btn btn-default" onclick="Defaultbutton()">Cancel</button>
		</div>
		
	  
	  </div>
    </div>
  </div>
</div>
<!--- **** --->





<style>
#test  td:hover {
    cursor: pointer;
}

#over.table>tbody>tr>td,#over.table>tbody>tr>th,#over.table>thead>tr>td,#over.table>thead>tr>th 
{
    padding: 10px;
    line-height: 1.42857143;
    vertical-align: top;
    border-top: none !important;
}


.img-responsive {
    border-radius: 50%;
	height:50px;
	width:50px;'
}

.validation1 {
    color: red;
    display:inline;
    font-weight:200;
    font-size:13px;
    font-weight:bold;
	margin-left:5px;
}

#Message
{
	display:none;
}

.glypicon_margin
{
	margin-right:10px !important;
	
}

</style>



<style>

	#tableborrow table
	{
		margin: 0;
		border-collapse: collapse;
	}
	
	#tableborrow td, #tableborrow th
	{
		padding: .5em 1em;
		border: 1px solid #999;
	}
	
	.table-container-outer { position: relative; }
	
	.table-container
	{
		width: 100%;
		overflow-y: auto;
		_overflow: auto;
		margin: 0 0 1em;
	}
	
	.table-container::-webkit-scrollbar
	{
		-webkit-appearance: none;
		width: 14px;
		height: 14px;
	}
	
	.table-container::-webkit-scrollbar-thumb
	{
		border-radius: 8px;
		border: 3px solid #fff;
		background-color: rgba(0, 0, 0, .3);
	}
	
	
</style>