<!-- Projects Row 3 -->
<div class="row">
		<div class="col-md-12" >

					<div class="col-md-12" >
						<span class="pull-left" style='font-size:25px'>List of Student</span>
						<button id='add_new_button' onclick="add_new_student()" class="btn btn-success btn-sm pull-right" >
							<span  class="glyphicon glyphicon-plus m-right"></span>Add New Student
						</button>
					</div>
				
					
		
					 <div class="page-header"></div>
					<div class="clear_space_small"></div>
					
					<div class="col-md-12" >
						<div id="Message"  role="alert">
							<strong>Well done! </strong><span id="msg_result"></span>
						</div>
					</div>
					
					
					
					<div class="panel-body">
							<table id='test' class="table table-bordered table-hover">
								<thead>
									<tr>
										<th>FirstName</th><th>LastName</th><th>Address</th><th>Email</th><th>Password</th><th>Phone</th><th>Gender</th><th>Dob</th>
										<th width='20%'>Action</th>
									</tr>
									
								</thead>
								<tbody>
								
								
								</tbody>
							</table>	
					</div>
		</div>
</div>
<!--  END OF ROW 3  -->
			

<script>
var save_method; //for save method string


$(document).ready(function(){
	
	loadstudent_detail();

});



function loadstudent_detail()
{
		
	var container = $("#test > tbody");
	var dataTable;
	
	 $.ajax({
		 
			url			:	"<?php echo site_url('student/get_all_student_data')?>",
			dataType 	: 	"JSON",
			
			beforeSend	: function(){
							
			},
			success		:	function(response)
			{
				
				if(response.length > 0)
				{
						container.empty();
						$.each(response, function(i,res){
							console.log(res);
						
									
									
								dataTable += '<tr>';
										
										dataTable += '<td>' + res.fname + '</td>';
										dataTable += '<td>' + res.lname + '</td>';
										dataTable += '<td>' + res.address + '</td>';
										dataTable += '<td>' + res.email_add + '</td>';
										dataTable += '<td>' + res.password + '</td>';
										dataTable += '<td>' + res.phone + '</td>';
										dataTable += '<td>' + res.gender + '</td>';
										dataTable += '<td>' + res.dob + '</td>';
										
										dataTable += "<td>";
										
											dataTable += "<a class='btn btn-raised btn-primary button_width' onclick=\"editStudent('"+res.id+"');\" href='#'  title='modify Customer'><i class='glyphicon glyphicon-pencil glypicon_margin'></i>Edit</a>&nbsp;";
											
											dataTable +="<a class='btn btn-raised btn-danger button_width' onclick=\"deleteData('"+res.id+"')\"  href='#' title='Delete Customer'><i class='glyphicon glyphicon-trash glypicon_margin'></i>Delete</a>";
											
										dataTable += "</td>";
									
								dataTable += '</tr>';
			
						});

				}
				else
				{
					dataTable += '<tr>';
					dataTable += '<td colspan="10" ><center>No Data Found !!!!</center></td>';	
					dataTable += '</tr>';
				}		
							
				container.hide().append(dataTable).animate({ opacity: "show" }, "slow"); // append student data display on table
			}
			
		}); 
		
}


function add_new_student()
{
    save_method = 'add';
    $('#Addnewstudent')[0].reset(); // reset form on modals
    $('.form-group').removeClass('has-error'); // clear error class
    $('#student_modal').modal('show'); // show bootstrap modal
    $('.modal-title').text('Add Student'); // Set Title to Bootstrap modal title
	RemoveError(); //remove validate error
}


/****************

get the data by id

****************/
function editStudent(id)
{
        

	save_method = 'update';
    $('#Addnewstudent')[0].reset(); // reset form on modals
    $('.form-group').removeClass('has-error'); // clear error class
	RemoveError();

    //Ajax Load data from student table
    $.ajax({
			url 		: "<?php echo site_url('student/get_student_data_byID')?>",
			data		: {"id":id}	,
			type		: "POST",
			dataType	: "JSON",
			success		: function(data){
				
				
							$('[name="id"]').val(data.id);
							$('[name="fname"]').val(data.fname);
							$('[name="lname"]').val(data.lname);
							$('[name="gender"]').val(data.gender);
							$('[name="address"]').val(data.address);
							$('[name="email_add"]').val(data.email_add);
							$('[name="password"]').val(data.password);
							$('[name="phone"]').val(data.phone);
							$('[name="dob"]').val(data.dob);
							$('#student_modal').modal('show'); // show bootstrap modal when complete loaded
							$('.modal-title').text('Edit Student'); // Set title to Bootstrap modal title

			},
			error: function (jqXHR, textStatus, errorThrown){
				alert('Error get data from ajax');
			}
    });


}


/**************

Display All error 
All field sthat need to input by the user
**************/

function DisplayError(results)
{
	
	if (results.length > 0) { 
		// iterating through the results array
		for(var i = 0; i < results.length; i++) {  
			var columnsIn = results[i];
			// loop through every key in the object
			for(var key in columnsIn){
				
				//display the column name and its value
				//console.log(key + ' : ' + results[i][key]); 
				
				 $("#val_"+key).css('display','inline').empty().append(results[i][key]);
				
			} 
		}
	}
}





/****************

funtion save - add new record and update existing  data
******************/
function save()
{
    $('#btnSave').text('saving...'); //change button text
    $('#btnSave').attr('disabled',true); //set button disable 
    var url;

    if(save_method == 'add') {
        url = "<?php echo site_url('student/add_student_data')?>";
    } else {
        url = "<?php echo site_url('student/update_student_data')?>";
    }

    // save data to database
    $.ajax({
        url : url,
        type: "POST",
        data: $('#Addnewstudent').serialize(),
        dataType: "JSON",
        success: function(data)
        {
		
            if(data.status === true) //if success close modal and reload student table
            {
                $('#student_modal').modal('hide');
				loadstudent_detail();
				showMessage(data.msg_result,data.addclass); // dispaly the successful message 
				setTimeout(function(){hideMessage() },3000);
            }
			else if(data.status === false) //Display Error 
			{
				DisplayError(data.error);	
			}

            $('#btnSave').text('save'); //change button text
            $('#btnSave').attr('disabled',false); //set button enable 

        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error adding / update data');
            $('#btnSave').text('save'); //change button text
            $('#btnSave').attr('disabled',false); //set button enable 

        }
    });
}




/************************

Confirm before deleting the record

***********************/
function deleteData(id)
{
	
	bootbox.confirm({
	 message: 'Do you really want to "DELETE" this record?',
	 buttons: { 'cancel': { label: 'Cancel', className: 'btn-default' },
			   'confirm': { label: 'Delete', className: 'btn-danger'} },
		
		callback: function(result) {
		  
			if(result){
					// ajax delete data to database
					$.ajax({
						url 	 : "<?php echo site_url('student/delete_student_data')?>/"+id,
						type	 : "POST",
						dataType : "JSON",
						success	 : function(data)
						{
							
							if(data.status === true) //if success load table and display confirmation 
							{
								loadstudent_detail();
								showMessage(data.msg_result,data.addclass); // dispaly the successful message for deleted 
								setTimeout(function(){hideMessage() },3000);
							}
						},
						error: function (jqXHR, textStatus, errorThrown)
						{
							alert('Error deleting data');
						}
					});			
			}
			
		}
	});
}







function RemoveError()
{
	$(".validation1").empty().css("display","none");
}


function hideMessage()
{
    $("#Message").fadeOut('slow');
}


function showMessage(msg_result,addclass)
{	
	$("#Message").removeAttr( "class" );
	$("#Message").addClass(addclass);
    $("#Message").css("display","block");
	$("#Message #msg_result").text(msg_result);
	
}




</script>


<div class="modal fade" id="student_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
  <div class="modal-dialog modal-lg modal-80p" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			<h3 class="modal-title">Person Form</h3>
      </div>
      <div class="modal-body">
       <form id="Addnewstudent" method ="post">
			   <input type="hidden" value="" name="id" id="id"/> 
			   
			   <div class="col-sm-6">
			   
					<div class="form-group">
						<label for="fname" class="control-label">Firstname:</label>
						<input  type="text" name="fname" id="fname" tabindex="1" class="form-control" placeholder="**please input first name" value="">
						<span class="validation1" id='val_fname' ></span>
					</div>
					
					<div class="form-group">
						<label for="lname" class="control-label">Lastname:</label>
						<input  type="text" name="lname" id="lname" tabindex="2" class="form-control" placeholder="**please input last name" value="">
						<span class="validation1" id='val_lname' ></span>
						
					</div>
					
					<div class="form-group">
						<label for="address" class="control-label">Address:</label>
						<input  type="text" name="address" id="address" tabindex="3" class="form-control" placeholder="**please input address" value="">
					</div>
					
					<div class="form-group">
							<label for="gender" class="control-label">Gender</label>
							 <select name="gender" id="gender" class="form-control">
										<option value="">--Select Gender--</option>
										<option value="male">Male</option>
										<option value="female">Female</option>
							</select>
					</div>
			   
			   </div>
			   
			   <div class="col-sm-6">
				
					<div class="form-group">
						<label for="email_add" class="control-label">Email Address:</label>
						<input  type="text" name="email_add" id="email_add" tabindex="4" class="form-control" placeholder="**please input email Address" value="">
						<span class="validation1" id='val_email_add' ></span>
					</div>

					<div class="form-group">
						<label for="password" class="control-label">Password:</label>
						<input type="password" name="password" id="password" tabindex="5" class="form-control" placeholder="**please input password">
						<span class="validation1" id='val_password' ></span>
					</div>

					<div class="form-group">
						<label for="phone" class="control-label">Phone number:</label>
						<input  type="text" name="phone" id="phone" tabindex="6" class="form-control" placeholder="**please input phone number" value="">
					</div>
					
					<div class="form-group">
							<label for="Dob" class="control-label">Date of Birth</label>
							<input name="dob" id="dob" placeholder="yyyy-mm-dd" class="form-control" type="date">	
					</div>
					
			   </div>
			   
		</form>
			  
			  <div class="clear_space_small"></div>
			  
	  </div>
	  <div class="modal-footer">
			<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			<button type='button' id='save-data' class='btn btn-primary'  onclick="save()" >Save Data</button>
	  </div>
	  
    </div>
  </div>
</div>


<style>
.validation1 {
    color: red;
    display:inline;
    font-weight:200;
    font-size:13px;
    font-weight:bold;
	margin-left:5px;
}

#Message
{
	display:none;
}

modal-80p {
    width:80%; /* 80% of page to provide space for labels */
  }

</style>


