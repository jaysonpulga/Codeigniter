<?php  $this->load->helper('url');	?>

<!-- Projects Row 2 -->
<div class="row">

		<div class="col-md-6" >
				<div class="well">
						
						
						<form action="#">
							<div class="input-group">
								<label class="sr-only" for="search-form">Search the site</label>
								<input type="text" class="form-control" id="search_student">
								<span class="input-group-btn">
									<button onclick="student()" class="btn btn-default" type="button">
										<span class="glyphicon glyphicon-search"></span>
										<span class="sr-only">Search</span>
									</button>
								</span>
							</div>
						</form>
						
						<!-- clear space -->	
						<div class="clear_space_small"></div>
						<!-- end of clear space -->
							
						<!-- Panel -->
						<div class="panel panel-default">
							<div class="panel-heading">
								<h4 class="panel-title">List of student</h4>
							</div>
							<div class="panel-body">
							
									<table  id="student_tbl" class="table table-bordered table-hover">
										<thead>
											<tr>
												<th>First Name</th><th>Last Name</th>
											</tr>
										</thead>
										<tbody>
										</tbody>
									</table>
							</div>
						</div>
							
				</div>
		</div>
				
		<div class="col-md-6">
				<div class="well">
					
					
						<form action="#">
							<div class="input-group">
								<label class="sr-only" for="search-form">Search the site</label>
								<input type="text" class="form-control" id="search_book">
								<span class="input-group-btn">
									<button onclick="Get_all_borrow_books('')" class="btn btn-default" type="button">
										<span class="glyphicon glyphicon-search"></span>
										<span class="sr-only">Search</span>
									</button>
								</span>
							</div>
						</form>
						
						<!-- clear space -->	
						<div class="clear_space_small"></div>
						<!-- end of clear space -->
						
						<!-- Panel -->
						<div class="panel panel-default">
							<div class="panel-heading">
								<h4 class="panel-title">List of Books</h4>
							</div>
							<div class="panel-body">
							
									<table id="book_rent" class="table table-bordered table-hover">
										<thead>
											<tr>
												<th>Book<br>Title</th><th>Book<br>Due Date</th><th width="55%"></th>
											</tr>
										</thead>
										<tbody>
										</tbody>
									</table>

									
							</div>
						</div>
						
				</div>
		</div>
</div>
<!--  END OF ROW 2  -->


<script>



$(document).ready(function(){
	
	
	student();
	Get_all_borrow_books();
});



function student()
{
		
	var container = $("#student_tbl > tbody");
	var dataTable;
	
	 $.ajax({
		 
			url			:	"<?php echo site_url('borrow/get_all_student_who_borrow')?>",
			data		:  {"search_student":$("#search_student").val()},
			type		: "POST",
			dataType 	: 	"json",
			
			beforeSend	: function(){
				
				
						
			},
			success		:	function(response)
			{
				
				if(response.length > 0)
				{
						container.empty();
						$.each(response, function(i,res){
							console.log(res);
						
									
									
								dataTable += '<tr  onclick=\"Get_all_borrow_books('+res.id+');\">';
										
										dataTable += '<td>' + res.fname + '</td>';
										dataTable += '<td>' + res.lname + '</td>';
																			
								dataTable += '</tr>';
			
						});
				
				
		
				}
				else
				{
					dataTable += '<tr>';
					dataTable += '<td colspan="10" ><center>No Data Found !!!!</center></td>';	
					dataTable += '</tr>';
				}		
							
				//container.append(dataTable);
				container.empty().hide().append(dataTable).animate({ opacity: "show" }, "slow");
			}
			
		}); 
		
}







function Get_all_borrow_books(id="")
{
		
	var container = $("#book_rent > tbody");
	var dataTable;
	
	 $.ajax({
			
			url			:	"<?php echo site_url('borrow/get_all_borrow_books')?>",
			data 		:	{"student_id":id,"search_book":$("#search_book").val()},
			method 		:   "POST",
			dataType 	: 	"JSON",
			
			beforeSend	: function(){
						
			},
			success	:	function(response)
			{
				
				if(response.length > 0)
				{
						container.empty();
						$.each(response, function(i,res){
							console.log(res);
						
									
									
								dataTable += '<tr>';
										
										dataTable += '<td>' + res.title + '</td>';
										dataTable += '<td>' + res.due_date + '</td>';
										
										dataTable += "<td>";
										
											dataTable += "<a class='btn btn-sm btn-success button_width' href='#' onclick=\"view_deatil("+res.borrow_id+");\"><i class='glyphicon glyphicon-eye-open m-right'></i>View Detail</a>";
											
											dataTable +="<a class='btn btn-sm btn-warning button_width '  href='#' title='return book' onclick=\"returnBook("+res.borrow_id+","+res.bookid+",\'"+res.title+"'\,\'"+res.due_date+"'\);\" ><i class='glyphicon glyphicon-refresh m-right'></i>Return Book</a>";
											
										dataTable += "</td>";
										
																			
								dataTable += '</tr>';
			
						});
				
				
		
				}
				else
				{
					dataTable += '<tr>';
					dataTable += '<td colspan="10" ><center>No Record</center></td>';	
					dataTable += '</tr>';
				}		
							
				container.empty().hide().append(dataTable).animate({ opacity: "show" }, "slow");
			}
			
		}); 
		
}






function view_deatil(borrow_id)
{	

	
	
	//Ajax Load data from borrow, books and student table
    $.ajax({
			url 		: "<?php echo site_url('borrow/borrow_details')?>",
			data		: {"borrow_id":borrow_id}	,
			type		: "POST",
			dataType	: "JSON",
			success		: function(data){
				
			
							$('#title').empty().append(data.title);
							$('#author').empty().append(data.author);
							$('#genre').empty().append(data.genre);
							$('#borrow_date').empty().append(data.borrow_date);
							$('#due_date').empty().append(data.due_date);
							$('#fullname').empty().append(data.fullname);
							$('#image_src').attr("src","<?php echo base_url('assets/book_image/')?>"+data.images);
							
						
			},
			error: function (jqXHR, textStatus, errorThrown){
				alert('Error get data from ajax');
			}
    });
	
var options = { backdrop : 'static'}
$('#book_detail').modal(options); // show bootstrap modal when complete loaded
	
	
}




function returnBook(borrow_id,bookid,title,due_date)
{



$("#book_title").empty().text(title);
$("#book_duedate").empty().text(due_date);

$("#bookid").val(bookid);
$("#borrow_id").val(borrow_id);
var options = { backdrop : 'static'}
$('#return_book').modal(options); // show bootstrap modal when complete loaded
	
}


function updateReturnBook()
{
	

	if($("#date_return").val() == ""){
		$("#val_date_return").css('display','block').empty().text("Date of return is required field");
		return false;
	}

	$.ajax({
			url 	: "<?php echo site_url('borrow/book_return')?>",
			data 	: $('#bookreturn').serialize(),
			type	: "POST",
			dataType : "JSON",
			success	 : function(data){
				
				if(data.status === true) //if success close modal and reload student table
				{
					$('#return_book').modal('hide');
					Get_all_borrow_books(id=""); // reload books borrow table
					bootbox.alert(data.msg_result);
				}
				
			},
			error: function (jqXHR, textStatus, errorThrown){
				alert('Error get data from ajax');
			}
	});

	
}


</script>


<!--- **** --->
<div class="modal fade" id="book_detail" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			<h4 class="modal-title">
				Book Detail
			</h4>
      </div>
      <div class="modal-body">
			<div class="row">
					<div class="col-md-6">
						<center>
							<img id="image_src" style="height:auto;width:80%">
						</center>
					</div>
					<div class="col-md-6">
						
							<div style="margin-top:20px">
								
										<table  id="over" class="table">
										
											<tbody>
												<tr>
													<td><strong>Book Title</strong></td>
													<td>:</td>
													<td class="pull-left" id="title"></td>
												</tr>
												
												<tr>
													<td><strong>Author</strong></td>
													<td>:</td>
													<td class="pull-left" id='author'>James Watte</td>
												</tr>
												
												<tr>
													<td><strong>Genre</strong></td>
													<td>:</td>
													<td class="pull-left" id='genre'>Horor/Suspence</td>
												</tr>
												<tr>
													<td><strong>Borrow Date</strong></td>
													<td>:</td>
													<td class="pull-left" id='borrow_date'>2017/01/10</td>
												</tr>
												
												<tr>
													<td><strong>Due Date</strong></td>
													<td>:</td>
													<td class="pull-left" id='due_date'>2017/01/12</td>
												</tr>
												<tr>
													<td><strong>Borrower</strong></td>
													<td>:</td>
													<td class="pull-left" id='fullname'>Andy Berson</td>
												</tr>
											</tbody>
																				
										</table>
								
							</div>		
					</div>	
			</div>
	  
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<!--- **** --->







<div class="modal fade" id="return_book" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
  <div class="modal-dialog modal-sm" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			<h4 class="modal-title">
				Return Book
			</h4>
      </div>
      <div class="modal-body">
			<div class="row">
				<form id="bookreturn" method ="post">
					<div class="col-md-12">
							<input type="hidden" value="" name="borrow_id" id="borrow_id"/> 
							<input type="hidden" value="" name="bookid" id="bookid"/> 
	
							<div class="form-group">
									<label for="date_return" class="control-label">Book Name:</label>
									<span id="book_title" >Sample</span>
							</div>
							
							<div class="form-group">
									<label for="date_return" class="control-label">Date Due:</label>
									<span id="book_duedate">2017/01/01</span>
							</div>
							
							
							<div class="form-group">
									<label for="date_return" class="control-label">Date of Return</label>
									<input name="date_return" id="date_return" placeholder="yyyy-mm-dd" class="form-control" type="date">
									<span class="validation1" id='val_date_return' ></span>								
							</div>
							
							
							<div class="form-group">
									<label for="Remarks" class="control-label">Remarks</label>
									<textarea name="remarks" id="remarks" placeholder="Remarks" class="form-control"></textarea>	
							</div>
					</div>
				</form>	
			</div>
	  
      </div>
      <div class="modal-footer">
	  
		<button type='button' id='save-data' class='btn btn-primary'  onclick="updateReturnBook()" >Update</button>
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
		
      </div>
    </div>
  </div>
</div>









<style>
#over.table>tbody>tr>td,#over.table>tbody>tr>th,#over.table>thead>tr>td,#over.table>thead>tr>th 
{
    padding: 10px;
    line-height: 1.42857143;
    vertical-align: top;
    border-top: none !important;
}

#student_tbl  td:hover, #book_rent td:hover
{
    cursor: pointer;
}


.validation1
{
    color: red;
    display:none;
    font-weight:200;
    font-size:13px;
    font-weight:bold;
	margin-left:5px;
}


</style>
