<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class books extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('model_books');
        $this->load->helper('form');
		$this->load->helper('url');
 		
	}

	public function index()
	{	
		
	}
	
	
	public function get_all_book_data()
	{
		$data = array();
		$data = $this->model_books->Get_all_Books();
		echo json_encode($data);
	}
	
		
	public function InputData()
	{
		
		$book_data = array(
				'title' => $this->input->post('title'),
				'author' => $this->input->post('author'),
				'book_dir' => $this->input->post('book_dir'),
				'genre' => $this->input->post('genre'),
				'date' => $this->input->post('date')
			);
			
		$this->load->library('form_validation');
		
		$this->form_validation->set_rules('title', 'title', 'required')
							  ->set_rules('author', 'author', 'required')
							  ->set_rules('book_dir', 'book directory', 'required')
							  ->set_rules('genre', 'genre', 'required')
							  ->set_rules('date', 'date', 'required')
							  ->set_error_delimiters('', '');

		
		
		if ($this->form_validation->run() == FALSE)
		{
			
			$error_data[] = array(
                'title' => form_error('title'),
                'author' => form_error('author'),
                'book_dir' => form_error('book_dir'),
				'genre' => form_error('genre'),
				'date' => form_error('date')
            );
			
			
			echo json_encode(array("status" => False,'error' =>$error_data));
			exit();
			// exit action add data return false
			
		}
		else
		{
			//// return data validate
			return $book_data;
		}
		
		
	}
	
	public function generate_code()
	{
			return rand(1,1000);
	}
	
	
	public function upload_image($image,$bookid,$img_current_name="")
	{
	
		
		$config['upload_path'] = './assets/book_image/';
		$config['allowed_types'] = 'gif|jpg|png|doc|txt';
		//$config['max_width'] = 1024;
		//$config['max_height'] = 1024;
		//$config['encrypt_name'] = TRUE;
		//$config['overwrite'] = TRUE;

		$this->load->library('upload', $config);
		if (!$this->upload->do_upload($image))
		{
			
		
			
			$error_data[] = array( 'userfile' => $this->upload->display_errors('', ''));				
			echo json_encode(array('status' => FALSE , 'error' =>$error_data));
			// exit if error on uploading image
			exit();
		}
		else
		{
			
			/// genereate new name of images add and update function
			$newname = $this->generate_code()."_".$bookid.".png";
			

			// this medthod is for updating image,Delete the current path  and create new path name and save to db
			if($img_current_name != "default_image.png" AND !empty($img_current_name))
			{	
				$localfile = unlink("assets/book_image/".$img_current_name);
			}
			
			//proceed to upload image and rename it
			$data = $this->upload->data();
			rename($data['full_path'],$data['file_path'].$newname);
			
			
			// update image column on books table 
			$bookname = array('images' => $newname);
			$book_id  = array('id' => $bookid);
			$update = $this->model_books->Updatebook($book_id,$bookname);

		}
		@unlink($_FILES["userfile"]);
				
	}
	
	
	
	
	
	
	
	public function add_book_data()
	{
		
		$data = $this->InputData(); /// check input by user if it's correct
		$bookid = $this->model_books->Savebook($data); // insert new data  into boks table and return id
		
		
		/*****
		If not empty upload image goto upload image and name it as return name from insert data 
		*****/
		if(!empty($_FILES["userfile"]["name"]))
		{
			//Call funtion "upload_image"  and  proceed to upload image create a new image
			$this->upload_image("userfile",$bookid);
		}
		else
		{
			// proceed if no image uploaded upon creating new book
			$bookname = array('images' => "default_image.png");
			$book_id  = array('id' => $bookid);
			$update = $this->model_books->Updatebook($book_id,$bookname);
				
		}
		
		$data = array(
					"status" 	 => TRUE,
					"msg_result" => "You have successfully insert new record.",
					"addclass"   => "alert alert-success"
					);
		
		
		echo json_encode($data);

	}
	
	public function update_book_data()
	{
		$data = $this->InputData(); /// check input by user if it's correct
		$update =  $this->model_books->Updatebook(array('id' => $this->input->post('id')),$data); // update book data
		
		
		/*****
		If not empty upload image goto upload image and name it as return name from insert data 
		*****/
		if(!empty($_FILES["userfile"]["name"]))
		{
			// get the current image path name book table
			$getpath_img = $this->model_books->getImagespath($this->input->post('id'));
			$id = $this->input->post('id');
			
			//Call funtion "upload_image"  and  proceed to upload and overwrite the current image of book
			$this->upload_image("userfile",$id,$getpath_img);
		}
		
		$data = array(
					"status" 	 => TRUE,
					"msg_result" => "Records are updated successfully.",
					"addclass"   => "alert alert-info"
					);
		
		
		echo json_encode($data);
		
	}
		
	
	
	function get_book_data_byID()
	{
		
		$id = $this->input->post('id');
		$data = array();
		$data = $this->model_books->Get_book_byID($id);
		echo json_encode($data);
		
		
	}
	
	
	function get_borrowbook_Details_byID()
	{
		
		$book_id = $this->input->post('book_id');
		$data = array();
		$data = $this->model_books->Get_borrowbook_DetailbyID($book_id);
		echo json_encode($data);
		
		
	}
	
	
	
	
	
	
}