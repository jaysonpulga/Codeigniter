<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class student extends CI_Controller {



	public function __construct()
	{
		parent::__construct();

		$this->load->model('model_student');
	}
	

	
	
	public function index()
	{	
		$this->load->helper('url');
		
	}
	
	
	public function callliststudent()
	{
		$data = array();
		$data = $this->model_student->Get_all_Student();
		return $data;
		
	}
	

	public function get_all_student_data()
	{
		
		$data = array();
		$data = $this->model_student->Get_all_Student();
		echo json_encode($data);
	}
	
	public function InputData()
	{
		
		$student_data = array(
				'fname' => $this->input->post('fname'),
				'lname' => $this->input->post('lname'),
				'address' => $this->input->post('address'),
				'email_add' => $this->input->post('email_add'),
				'password' => $this->input->post('password'),
				'phone' => $this->input->post('phone'),
				'gender' => $this->input->post('gender'),
				'dob' => $this->input->post('dob')
			);
			
		$this->load->library('form_validation');
		
		$this->form_validation->set_rules('fname', 'first name', 'required')
							  ->set_rules('lname', 'last name', 'required')
							  ->set_rules('email_add', 'email addres', 'required|valid_email')
							  ->set_rules('password', 'password', 'required')
							  ->set_error_delimiters('', '');

		
		
		if ($this->form_validation->run() == FALSE){
			
			$error_data[] = array(
                'fname' => form_error('fname'),
                'lname' => form_error('lname'),
                'email_add' => form_error('email_add'),
				'password' => form_error('password')
            );
			
			
			echo json_encode(array("status" => False,'error' =>$error_data));
			exit();
			// exit action add data return false
			
		}
		else
		{
			
			return $student_data;
		}
		
		
	}
	
	
	public function add_student_data()
	{
		$data = $this->InputData(); /// check data input return data if no error 
		
		$insert = $this->model_student->Savestudent($data);
		
		$data = array(
					"status" 	 => TRUE,
					"msg_result" => "You have successfully insert new record.",
					"addclass"   => "alert alert-success"
					);
		
		
		echo json_encode($data);
	}
	
	public function update_student_data()
	{
		$data = $this->InputData(); /// check data input return data if no error 
		
		$update = $this->model_student->Updatestudent(array('id' => $this->input->post('id')),$data);
		
		$data = array(
					"status" 	 => TRUE,
					"msg_result" => "Records are updated successfully.",
					"addclass"   => "alert alert-info"
					);
		
		echo json_encode($data);
	}
	
	
	public function delete_student_data($id)
	{
		
		$delete = $this->model_student->Deletestudent($id);
		
		$data = array(
					"status" 	 => TRUE,
					"msg_result" => "You have successfully delete the record.",
					"addclass"   => "alert alert-danger"
					);
		
		echo json_encode($data);
	}
	
	
	public function get_student_data_byID()
	{
		$id = $this->input->post('id');
		$data = array();
		$data = $this->model_student->Get_student_byID($id);
		echo json_encode($data);
		
	}
	
	
	
}