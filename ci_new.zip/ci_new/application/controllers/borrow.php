<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class borrow extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('model_borrowbooks');
	}

	public function index()
	{	
		$this->load->helper('url');
	}
	
	

	
	public function get_all_student_who_borrow()
	{
		$search_student = $this->input->post('search_student');	
		$data = array();
		$data = $this->model_borrowbooks->Get_all_student_who_borrow($search_student);
		echo json_encode($data);
	}
	
	
	
	public function get_all_borrow_books()
	{
		@$student_id = $this->input->post('student_id');
		@$search_book = $this->input->post('search_book');
		
		
		
		$data = $this->model_borrowbooks->get_all_borrow_books($student_id,$search_book);
		echo json_encode($data);
	}
	

	
	
	public function borrow_details()
	{
		$borrow_id = $this->input->post('borrow_id');
		$data = array();
		$data = $this->model_borrowbooks->get_borrow_details($borrow_id);
		echo json_encode($data);
	}
	
	public function InputData()
	{
		
		$borrow_data = array(
				'student_id' => $this->input->post('student_list'),
				'borrow_date' => $this->input->post('date_borrow'),
				'due_date' => $this->input->post('date_due'),
				'book_id' => $this->input->post('bookid'),
				'borrow_status' => "borrow");
			
		$this->load->library('form_validation');
		
		$this->form_validation->set_rules('student_list', 'Student', 'required')
							  ->set_rules('date_borrow', 'Borrow date', 'required')
							  ->set_rules('date_due', 'Date due', 'required');
							//->set_error_delimiters('', '');

	
		if ($this->form_validation->run() == FALSE)
		{
			
			$error_data = array(
                'student_list' => form_error('student_list'),
                'date_borrow' => form_error('date_borrow'),
                'date_due' => form_error('date_due')
            );
			
			echo json_encode(array("status" => False,'error' =>$error_data));
			exit();
			// exit action add data return false
			
		}
		else
		{
			
			return $borrow_data;
		}
		
		
	}
	
	
	
	
	
	
	public function add_BookBorrow()
	{
		
		$data = $this->InputData(); /// check data input return data if no error 
		$this->model_borrowbooks->Saveborrow($data);
		
		// update status of book into out
		$updateStat = array('book_status' => "out");
		$where = array('id' => $this->input->post('bookid'));
		$this->model_borrowbooks->updateStatusbook($updateStat,$where);
		
		$data = array(
			"status" => TRUE,
			"msg_result" => "You have successfully insert new record.");
			
		echo json_encode($data);
		
	}
	
	public function update_BookBorrow()
	{		
				
		$data = $this->InputData(); /// check data input return data if no error 
		$data = $this->model_borrowbooks->Updateborrow(array('borrow_id' => $this->input->post('borrow_id')),$data);
		
		$data = array(
				"status" 	 => TRUE,
				"msg_result" => "Records are updated successfully.");
				
		echo json_encode($data);
		
	}
	
	public function book_return()
	{
		$data = array(
				'date_return' => $this->input->post('date_return'),
				'remarks' => $this->input->post('remarks'),
				"borrow_status" => "returned");
		
		$data = $this->model_borrowbooks->Updateborrow(array('borrow_id' => $this->input->post('borrow_id')),$data);
		
		
		// update status of book into available
		$updateStat = array('book_status' => "available");
		$where = array('id' => $this->input->post('bookid'));
		$this->model_borrowbooks->updateStatusbook($updateStat,$where);
		
		
		$data = array(
				"status" 	 => TRUE,
				"msg_result" => "Records are updated successfully.");
				
		echo json_encode($data);
		
	}

	public function borrowerbook($id)
	{
		$data = array();
		$data = $this->model_borrowbooks->get_borrowerbook($id);
		echo json_encode($data);
		
	} 
	
	
	
	
}