<?php
if(!defined('BASEPATH')) exit('No direct script access allowed');

class Dashboard extends CI_Controller
{
	public $obj;
	
	function __construct()
	{
		
		parent::__construct();
		
	}
		 
	
	

	
	public function index()
	{

		$this->load->helper('url');
		$this->renderpartialTemplate();
	}
	
	
	public static function callStudentController()
	{
		
		 require_once(APPPATH.'controllers/student.php'); //include controller
            $aObj = new student();  //create object 
			$data =  $aObj->callliststudent(); //call function
			return $data;
	}
	
	
	public function renderpartialTemplate()
	{
		
		$data['title'] = "Library System";
		
		$this->load->view("template/header", $data);
		$this->load->view("template/main");
		$this->load->view("template/footer");
		
		
	}
	
	public function load_page()
	{
		
		$page_name = $this->input->post('page_name');
		$this->load->view("pages/modal");
		$this->load->view("pages/".$page_name);
	
	}
	
	
	
}
?>